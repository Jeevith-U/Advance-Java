package com.SpringWithDB.SpringWithDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWithDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWithDbApplication.class, args);
	}

}
