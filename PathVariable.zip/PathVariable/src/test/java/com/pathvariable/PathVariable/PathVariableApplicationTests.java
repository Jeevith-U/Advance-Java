package com.pathvariable.PathVariable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PathVariableApplicationTests {

	@Test
	void contextLoads() {
	}

}
