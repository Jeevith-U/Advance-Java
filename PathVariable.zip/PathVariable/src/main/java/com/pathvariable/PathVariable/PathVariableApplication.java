package com.pathvariable.PathVariable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PathVariableApplication {

	public static void main(String[] args) {
		SpringApplication.run(PathVariableApplication.class, args);
	}

}
