package com.workingsapce.WorkSpace;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkSpaceApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkSpaceApplication.class, args);
	}

}
