package com.cookie.Cookie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CookieApplicationTests {

	@Test
	void contextLoads() {
	}

}
