package com.responseSturcture.ResponseStructure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResponseStructureApplicationTests {

	@Test
	void contextLoads() {
	}

}
