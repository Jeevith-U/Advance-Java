package com.responseSturcture.ResponseStructure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResponseStructureApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResponseStructureApplication.class, args);
	}

}
