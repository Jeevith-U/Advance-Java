package com.tyss.swagger.UserAppWithSwagger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserAppWithSwaggerApplicationTests {

	@Test
	void contextLoads() {
	}

}
