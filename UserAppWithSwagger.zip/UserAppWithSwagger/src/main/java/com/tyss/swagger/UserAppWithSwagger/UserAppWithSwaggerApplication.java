package com.tyss.swagger.UserAppWithSwagger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserAppWithSwaggerApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserAppWithSwaggerApplication.class, args);
	}

}
