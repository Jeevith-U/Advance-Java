package com.JSONInRequestBody.JSONInRequestBody;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonInRequestBodyApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsonInRequestBodyApplication.class, args);
	}

}
