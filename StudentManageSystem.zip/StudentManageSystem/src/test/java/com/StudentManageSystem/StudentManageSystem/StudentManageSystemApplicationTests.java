package com.StudentManageSystem.StudentManageSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentManageSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
