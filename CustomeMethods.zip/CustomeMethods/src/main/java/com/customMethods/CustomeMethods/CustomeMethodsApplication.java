package com.customMethods.CustomeMethods;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomeMethodsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomeMethodsApplication.class, args);
	}

}
