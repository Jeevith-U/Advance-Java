package com.customMethods.CustomeMethods;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomeMethodsApplicationTests {

	@Test
	void contextLoads() {
	}

}
